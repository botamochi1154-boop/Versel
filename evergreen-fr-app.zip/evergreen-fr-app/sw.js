/* EverGreen (fr) v1: 画面（HTML）はネットにつながっていれば最新版、つながらなければ保存済みを表示。画像は保存済みをすぐ表示 */
const V='evergreen-fr-v1';
const FILES=['./','index.html','manifest.json','apple-touch-icon-v12-4.png','icon-192-v12-4.png','icon-512-v12-4.png','img/hero-01.jpg','img/hero-02.jpg','img/hero-03.jpg','img/hero-04.jpg','img/hero-05.jpg','img/hero-06.jpg','img/hero-07.jpg','img/hero-08.jpg','img/hero-09.jpg','img/hero-10.jpg','img/hero-11.jpg','img/hero-12.jpg','img/thumb-01.jpg','img/thumb-02.jpg','img/thumb-03.jpg','img/thumb-04.jpg','img/thumb-05.jpg','img/thumb-06.jpg','img/thumb-07.jpg','img/thumb-08.jpg','img/thumb-09.jpg','img/thumb-10.jpg','img/thumb-11.jpg','img/thumb-12.jpg'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET'||u.origin!==location.origin)return;
  /* 画面と設定ファイルは最新を優先（3.5秒で返ってこなければ保存済み） */
  if(e.request.mode==='navigate'||/\/(index\.html)?$/.test(u.pathname)||u.pathname.endsWith('manifest.json')){
    e.respondWith(caches.open(V).then(c=>{const net=fetch(e.request).then(r=>{if(r&&r.ok)c.put(e.request,r.clone());return r;});
      const late=new Promise(res=>setTimeout(()=>res(null),3500));
      return Promise.race([net.catch(()=>null),late]).then(r=>r||c.match(e.request,{ignoreSearch:true}).then(h=>h||c.match('index.html')).then(h=>h||net));}));
    return;}
  e.respondWith(caches.open(V).then(c=>c.match(e.request,{ignoreSearch:true}).then(hit=>{
    const net=fetch(e.request).then(r=>{if(r&&r.ok)c.put(e.request,r.clone());return r;}).catch(()=>hit||c.match('index.html'));
    return hit||net;
  })));
});
